<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'yi', 'ding', 'kao', 'qi', 'shang', 'xia', 'han', 'wan', 'zhang', 'san', 'shang', 'xia', 'ji', 'bu', 'yu', 'mian',
  0x10 => 'gai', 'chou', 'chou', 'zhuan', 'qie', 'pi', 'shi', 'shi', 'qiu', 'bing', 'ye', 'cong', 'dong', 'si', 'cheng', 'diu',
  0x20 => 'qiu', 'liang', 'diu', 'you', 'liang', 'yan', 'bing', 'sang', 'gun', 'jiu', 'ge', 'ya', 'qiang', 'zhong', 'ji', 'jie',
  0x30 => 'feng', 'guan', 'chuan', 'chan', 'lin', 'zhuo', 'zhu', 'ha', 'wan', 'dan', 'wei', 'zhu', 'jing', 'li', 'ju', 'pie',
  0x40 => 'fu', 'yi', 'yi', 'nai', 'wu', 'jiu', 'jiu', 'tuo', 'me', 'yi', 'yi', 'zhi', 'wu', 'zha', 'hu', 'fa',
  0x50 => 'le', 'yin', 'ping', 'pang', 'qiao', 'hu', 'guai', 'cheng', 'cheng', 'yi', 'yin', 'ya', 'mie', 'jiu', 'qi', 'ye',
  0x60 => 'xi', 'xiang', 'gai', 'jiu', 'xia', 'hu', 'shu', 'dou', 'shi', 'ji', 'nang', 'jia', 'ju', 'shi', 'mao', 'hu',
  0x70 => 'mai', 'luan', 'zi', 'ru', 'xue', 'yan', 'fu', 'sha', 'na', 'gan', 'suo', 'yu', 'cui', 'zhe', 'gan', 'zhi',
  0x80 => 'gui', 'gan', 'luan', 'lin', 'yi', 'jue', 'le', 'ma', 'yu', 'zheng', 'shi', 'shi', 'er', 'chu', 'yu', 'kui',
  0x90 => 'yu', 'yun', 'hu', 'qi', 'wu', 'jing', 'si', 'sui', 'gen', 'gen', 'ya', 'xie', 'ya', 'qi', 'ya', 'ji',
  0xA0 => 'tou', 'wang', 'kang', 'ta', 'jiao', 'hai', 'yi', 'chan', 'heng', 'mu', 'ye', 'xiang', 'jing', 'ting', 'liang', 'xiang',
  0xB0 => 'jing', 'ye', 'qin', 'bo', 'you', 'xie', 'dan', 'lian', 'duo', 'men', 'ren', 'ren', 'ji', 'ji', 'wang', 'yi',
  0xC0 => 'shen', 'ren', 'le', 'ding', 'ze', 'jin', 'pu', 'chou', 'ba', 'zhang', 'jin', 'jie', 'bing', 'reng', 'cong', 'fo',
  0xD0 => 'san', 'lun', 'bing', 'cang', 'zi', 'shi', 'ta', 'zhang', 'fu', 'xian', 'xian', 'tuo', 'hong', 'tong', 'ren', 'qian',
  0xE0 => 'gan', 'ge', 'bo', 'dai', 'ling', 'yi', 'chao', 'chang', 'sa', 'shang', 'yi', 'mu', 'men', 'ren', 'jia', 'chao',
  0xF0 => 'yang', 'qian', 'zhong', 'pi', 'wo', 'wu', 'jian', 'jia', 'yao', 'feng', 'cang', 'ren', 'wang', 'fen', 'di', 'fang',
];
